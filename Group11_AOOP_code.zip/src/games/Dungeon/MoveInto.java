package games.Dungeon;

import engine.Entity;

public interface MoveInto{
    public boolean moveInto(DungeonMaster p, Entity e);
}