package games.Dungeon;

public interface Description {
    public String getName();
    public String getDescription();
    public void setInfo(String name, String description);
}
