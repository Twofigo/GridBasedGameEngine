package games.Sokoban;

import engine.Entity;

public interface MoveInto{
    public boolean moveInto(Sokoban p, Entity e);
}