# GridBasedGameEngine

We've tried for days to get it to compile into a jar, but java is being mean, and the default java version is missing dependencies to run it.

So this is it.


References:

